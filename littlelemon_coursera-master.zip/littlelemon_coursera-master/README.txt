API endpoints
/api/categories -> to get all categories
/api/menu-items -> to get all menu-items
/api/menu-items/<id> -> to get category by id
/api/book -> to get all books
/api/book/<id> -> to get book by id
/api-token-auth/ -> to get token

SUPERUSER
username: admin
password: admin
